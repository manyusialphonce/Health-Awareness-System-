<?php
// footer.php
?>
<footer>
    <div class="footer-content">
        <p>&copy; <?php echo date("Y"); ?> Health Awareness System. Haki zote zimehifadhiwa.</p>
        <p>Wasiliana nasi: info@healthsystem.co.tz</p>
    </div>
</footer>
<script src="js/script.js"></script>
</body>
</html>