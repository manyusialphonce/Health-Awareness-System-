<?php
// header.php
?>
<!DOCTYPE html>
<html lang="sw">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Awareness System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <div class="logo">
        <img src="images/logo.png" alt="Logo ya System">
    </div>
    <nav>
        <ul>
            <li><a href="index.php">Nyumbani</a></li>
            <li><a href="articles.php">Makala za Afya</a></li>
            <li><a href="symptom-checker.php">Chunguza Dalili</a></li>
            <li><a href="contact.php">Wasiliana Nasi</a></li>
        </ul>
    </nav>
</header>